#!/bin/sh
#
#
export JAVA_HOME=`/usr/libexec/java_home -v 17` 
export LANG=C
java --module-path ./DSMWorkbench_lib --add-modules=javafx.base,javafx.fxml,javafx.controls,javafx.swing,javafx.graphics,org.neo4j.driver,org.apache.logging.log4j,com.fasterxml.jackson.databind,org.apache.commons.csv,org.jgrapht.core,org.jgrapht.io,smartgraph,jung.combined -jar ./DSMWorkbench.jar
