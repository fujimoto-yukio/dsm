#!/bin/sh
# DSM Workbench ver 1.0
#
# Copyright 2024 FUJIMOTO, Yukio. All Right Reserved.
#

export JAVA_HOME=`/usr/libexec/java_home -v 17` 
STDOUT_LOG=$HOME/.dsmworkbench/stdout.log
STDERR_LOG=$HOME/.dsmworkbench/stderr.log
LOG4J_CONF=./log4j2-mac.xml

echo DSM Workbench ver 1.0 start
echo JAVA_HOME=$JAVA_HOME

java --module-path ./DSMWorkbench_lib --add-modules=javafx.base,javafx.fxml,javafx.controls,javafx.swing,javafx.graphics,org.neo4j.driver,org.apache.logging.log4j,com.fasterxml.jackson.databind,org.apache.commons.csv,org.jgrapht.core,org.jgrapht.io,smartgraph,jung.combined -Dlog4j.configurationFile=$LOG4J_CONF -jar ./DSMWorkbench.jar 1> $STDOUT_LOG 2> $STDERR_LOG
